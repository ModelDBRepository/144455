Random connectivity
===================
