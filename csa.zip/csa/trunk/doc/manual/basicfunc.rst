Basic functions
===============

Connection-set constructor
--------------------------

.. function:: cset (mask, valueSet, ...)

Selectors
---------

.. function:: mask (object)

.. function:: value (object, k)

.. function:: arity (object)

Cartesian product
-----------------

.. function:: cross (set1, set2)

Elementary masks
----------------



Support for parallel simulators
-------------------------------

.. function:: partition (cset, masks, selected[, seed])

Utilities
---------

.. function:: tabulate (cset)
