The Python CSA Reference Manual
===============================
Contents:

.. toctree::
   :maxdepth: 2

   intro
   datatypes
   basicfunc
   random
   geometry
   tutorial


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

